
public class Blinky extends Ghost {

	public Blinky(GameWorld gw) {
		super(gw);
	}

	@Override
	void findPath() {
		// TODO Auto-generated method stub

	}
}
