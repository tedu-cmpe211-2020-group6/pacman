
public class Pinky extends Ghost {

	public Pinky(GameWorld gw) {
		super(gw);
	}

	@Override
	void findPath() {
		// TODO Auto-generated method stub

	}

}
