
public enum Direction {
	up, right, down, left;
}
