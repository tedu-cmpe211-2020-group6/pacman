
public class Clyde extends Ghost {

	public Clyde(GameWorld gw) {
		super(gw);
	}

	public void findPath() {
		// TODO Manually generated method stub
	}
}
