
public class Inky extends Pinky {

	public Inky(GameWorld gw) {
		super(gw);
		// TODO Auto-generated constructor stub
	}

}
